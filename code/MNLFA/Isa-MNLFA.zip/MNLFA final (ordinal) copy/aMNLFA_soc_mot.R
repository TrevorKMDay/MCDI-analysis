# Code calls functions from aMNLFA.R 
# Note: Robin Sifre made some changes to the
# functions. Some were substantive changes (e.g. changing how family-wise error
# was adjusted for), and some were fixing some bugs that was causing the package
# to crash
#https://cran.r-project.org/web/packages/aMNLFA/index.html

####################################################
# Load libraries
####################################################
# 
# library(devtools)
# install_local("~/Downloads/aMNLFA_0.1.tar.gz")

library(aMNLFA)
library(MplusAutomation)
library(multiplex)
library(ggplot2)
library(dplyr)
####################################################
# Setting paths & reading in data 
####################################################
# Set directory to where script will output mplus files.
homedir <- '/Users/install/Desktop/SM MNLFA for testing/'
calib_sample = '1'
subscale = 'REP'
wd = homedir


# Read in cleaned RBS-EC data 
df <- read.csv(paste(homedir, 'for_mnlfa.csv', sep = ''),header=TRUE)
# df$Age= rowMeans(df[,c(2,15,27,39)], na.rm=T)

# For reproducibility, read in previously-generated calib_sample
# ru = read.csv(paste(homedir, 'MNLFA/output/calib_', calib_sample, '/calib_sample', calib_sample, '.csv', sep = ''))
# ru = data.frame(ru)

####################################################
# 1.	Define aMNLFA objects (aMNLFA.object) 
# Comment out subscale that is not currently being run. 
####################################################
# Repetitive motor --defining object to pass to model
# colnames(df)
df=as.data.frame(df)
df=df[,2:ncol(df)]
names(df) <- toupper(names(df))
# df$X=NULL
# df$IBQR_5=as.numeric(df$IBQR_5)

#actual item col names 
# "IBQR_5", "IBQR_6", "IBQR_67", "IBQR_79", "IBQR_80", "IBQR_103" , "IBQR_126", "IBQR_148","IBQR_149",  "IBQR_165",    
# "IBQR_172", "IBQR_173", 
# "V_rec_2", "V_exp_2", "V_ipr_4", "V_ipr_5", "V_ipr_8",  "V_ipr_12", 
# "FYI_12", "FYI_19", "FYI_20", "FYI_31",
# "M_A4"

#variable names cannot have periods or exceed 8 chars each and all must be capitalized
colnames(df)=c("ID", "X", "AGE","HR", "F", 
               "IB_5", "IB_6", "IB_67","IB_79","IB_80", "IB_103", "IB_126", "IB_148", "IB_149",
               "IB_165",  "IB_172", "IB_173", 
               "V_R_2", "V_E_2",  "V_I_4", "V_I_5", "V_I_8", "V_I_12", 
               "FYI_12" , "FYI_19", "FYI_20", "FYI_31", 
               "M_A4")

#rescaling ibqs to make them factors
ibqs=which(grepl("IB", colnames(df)))
for (i in 1:length(ibqs)){
  df[,ibqs[i]]=round(df[,ibqs[i]]*6,2)
}

df$HR=as.factor(df$HR)
df$F=as.factor(df$F)
df$V_R_2=as.factor(df$V_R_2)
df$V_E_2=as.factor(df$V_E_2)
df$V_I_4=as.factor(df$V_I_4)
df$V_I_5=as.factor(df$V_I_5)
df$V_I_12=as.factor(df$V_I_12)
df$V_I_8=as.factor(df$V_I_8)
df$FYI_12=as.factor(df$FYI_12)
df$FYI_19=as.factor(df$FYI_19)
df$FYI_20=as.factor(df$FYI_20)
df$FYI_31=as.factor(df$FYI_31)
df$M_A4=as.factor(df$M_A4)
# df$IB_5=as.factor(df$IB_5)
# df$IB_6=as.factor(df$IB_6)
# df$IB_67=as.factor(df$IB_67)
# df$IB_79=as.factor(df$IB_79)
# df$IB_80=as.factor(df$IB_80)
# df$IB_103=as.factor(df$IB_103)
# df$IB_126=as.factor(df$IB_126)
# df$IB_148=as.factor(df$IB_148)
# df$IB_149=as.factor(df$IB_149)
# df$IB_165=as.factor(df$IB_165)
# df$IB_172=as.factor(df$IB_172)
# df$IB_173=as.factor(df$IB_173)


 ob <-aMNLFA.object(dir          = wd, # location of data
                   mrdata        = df, #read in dataframe from R
                   indicators    = # list a set of indicators of a single factor; make names as short as possible
                      c( "IB_5", "IB_6", "IB_67","IB_79","IB_80", "IB_103", "IB_126", "IB_148", "IB_149",
                         "IB_165",  "IB_172", "IB_173", 
                         "V_R_2", "V_E_2",  "V_I_4", "V_I_5", "V_I_8", "V_I_12", 
                         "FYI_12" , "FYI_19", "FYI_20", "FYI_31", 
                         "M_A4"), 
                   catindicators =c( "V_R_2", "V_E_2",  "V_I_4", "V_I_5", "V_I_8", "V_I_12", 
                                     "FYI_12" , "FYI_19", "FYI_20", "FYI_31", 
                                     "M_A4"),
                     
                     #"V_R_2", "V_E_2",  "V_I_4", "V_I_5", "V_I_8", "V_I_12", "M_A4"),
                                     # "FYI_12" , "FYI_19", "FYI_20", "FYI_31", #these have 3 levels
                                    
                     # list a set of indicators that are binary or ordinal (categorical)
                   time        = "AGE", #age variable (can be centered)
                   #mean and var are for things you are substantively interested in
                   meanimpact    =  #what your moderators of interest are
                                     c("HR", "AGE", "F"), # Contrast coding of nominal variables
                   varimpact     = "AGE", # contrast coding of nominal variables; this is computational expensive; JUST DO TIME VARIABLE
                   #this part: specific indicators impacted by mods? should included all mean/var impact items
                   measinvar     = c("HR", "AGE", "F"), 
                   factors       = c("HR", "F"),#which of variables are factors
                   ID            = "ID",
                   auxiliary     = "X", 
                   thresholds    = FALSE) # indicate whether you would like to test measurement invariance of thresholds for ordinal indicators. SET TO TRUE. 
                      #seems to require at least one categorical indicator? this is computationally intensive!!!
                   
#robin has separate objects for each factor; cannot be simultaneously done for all factors
#must feel confident about factor going in; i.e., structural invariance
#make sure males and females have overall factor structure

####################################################
# 2.	Plot items over time
####################################################
# source(paste(homedir, 'aMNLFA_itemplots.R', sep='')) 
 
aMNLFA::aMNLFA.itemplots(ob) #can give clues to invariance, produces item plots over time for each other moderators in folder

#################################################### 
# 3.	Draw a calibration sample.
# Sample one calibration per ID. Outputs a calibration file. Was originally designed for independent obs. Build initial models w/ calib sample. 
#do for a couple of calibration samples to check robustness.
#################################################### 
# Author modified code to allow user to input calibration sample
# source(paste(homedir, 'aMNLFA_sample.R', sep='')) 
# aMNLFA.sample(ob,ru)
aMNLFA::aMNLFA.sample(ob) #produces calibration.dat, full.dat, header.tx, header2.txt, srdata.dat

#################################################### 
# Optional code - used for adding manual additions to MPLUS script 
# (e.g. constraining variance of moderators so model would converge)
#################################################### 
#calib.dat <- read.delim("/Users/sifre002/Desktop/Invariance/CalibSample2/REP_FIXED/calibration.dat", header=FALSE)
#vars = read.csv("/Users/sifre002/Desktop/Invariance/CalibSample2/REP_FIXED/vars.csv", header=TRUE)
#vars = vars$x
#colnames(calib.dat) = vars
#var(calib.dat$TABLET)
#var(calib.dat$MALE)

####################################################
# 4.	Create Mplus input files for mean impact, variance impact, 
# and item-by-item measurement non-invariance (aMNLFA.initial)
#makes initial models, populated in folder w/ MPlus input files wa
####################################################
source(paste(homedir, 'aMNLFA_initial.R', sep ='')) 
aMNLFA.initial(ob) #produces a series of measinvariance.imp files for each item, varimpact.imp, and meanimpact.imp
# Run Models in Mplus --check .out files to see if there are any errors!
runModels("/Users/Install/Desktop/SM MNLFA for testing/", replaceOutfile = 'always') # This will run all models in Mplus in the path you set. This will take some time. 

##################################
# 5. Incorporate all ‘marginally significant’ terms into a simultaneous Mplus input file;
################################
source(paste(homedir, 'aMNLFA_simultaneous.R', sep =''))
aMNLFA.simultaneous(ob)
runModels("/Users/Install/Desktop/SM MNLFA for testing/", replaceOutfile = 'always') #produces Mplus Run Models.log 
#Running this code results in a single Mplus script file (round2calibration.inp)
#	All mean and variance impact terms with p<.10 are included 

##################################
# 6. Trim non-sig terms.  
################################
# source(paste(homedir, 'MNLFA/scripts/aMNLFA_final.R', sep = ''))
aMNLFA.final(ob)
runModels("/Users/Install/Desktop/SM MNLFA for testing/", replaceOutfile = 'always') 

##################################
# 7. (only for longitudinal data) Use parameter values generated from the last calibration model to fix
# parameter values in the scoring model using the full, longitudinal dataset
################################
# source(paste(homedir, 'aMNLFA.scores.R', sep = '')) #added kevin's script
aMNLFA.scores(ob)
#The resulting Mplus script uses the long (mr.dat) data file and outputs factor
# score estimates for each observation. Run the resulting scores.inp script manually.
# This script produces a file containing factor score estimates if data are cross-sectional.


##################################
# 8. Describe and visualize factor score estimates and generate empirical item
# characteristic curves
##################################
# NOTE: Step 7 saves "scores.dat" in the wrong directory (was in my root dir). 
# Need to move this file to wdir before running this last line. 
source(paste(homedir,'aMNLFA_scoreplots.R', sep = ''))
aMNLFA.scoreplots(ob)

